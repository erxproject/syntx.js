### [1.1.0] - 2026-06-19 — discord.js 14.26.4 update
> Reminder / "recordatorio" of everything that was added, changed and fixed, and **why**.

#### New features (discord.js 14.16 → 14.26)
- **`Display` (Components V2)** — new class in `src/classes/components/display.js`.
  Lets you build Discord's new "Components V2" message layout (text, separators,
  sections, galleries, files, containers, buttons and select menus) with the same
  JSON-first syntax as the rest of the library. *Why:* Components V2 is the biggest
  addition to discord.js since 14.15 and the feature you specifically asked for.
- **`Poll`** — new class in `src/classes/poll.js` for native Discord polls
  (`cmd.message.send({ poll: poll.build() }, msg)`). *Why:* polls were added to the
  Discord API in 2024 and supported from discord.js 14.16; the library had no way to use them.
- **Premium (SKU) buttons** — `Buttons` and `Display` now support
  `{ style: "premium", sku: "<id>" }`. *Why:* `ButtonStyle.Premium` was added in 14.16.
- **User-installable apps & contexts on slash commands** — `SlashCommand` now accepts
  `integrationTypes: ["guild","user"]` and `contexts: ["guild","bot_dm","private_channel"]`,
  plus `nsfw` and `defaultMemberPermissions`. *Why:* user-installable apps landed in 14.16
  (`setIntegrationTypes` / `setContexts`).
- **`silent` messages** — `cmd.message.send({ ..., options: { silent: true } })` sends with
  `SuppressNotifications`. *Why:* exposes an existing message flag that was missing.

#### Fixes
- **FIXED (critical): broken polls.** `Poll` was emitting answers as
  `{ pollMedia: { text, emoji } }`, but discord.js reads each answer's `text`/`emoji`
  **directly** off the answer object (`MessagePayload` maps them into `poll_media`).
  The result was polls being sent with empty answers / API errors. Answers are now flat
  (`{ text, emoji }`), which matches what discord.js 14.26 expects.
- **FIXED: button styles as strings.** Passing `style: "Primary"` into a `ButtonBuilder`
  threw a validation error because the builder only accepts the numeric `ButtonStyle` enum.
  Styles are now resolved from friendly strings ("Primary", "Link", "Premium", ...) to the enum.
- **FIXED: slash commands.** `SlashCommand` was rebuilt on top of `SlashCommandBuilder` with
  validation (name/description required, options cannot be mixed with subcommands/groups,
  unsupported option types throw a clear error) and `choices` may now be `["Red","Blue"]` or
  `[{ name, value }]`. This addresses the "SlashCommand gives an error / doesn't work as expected".
- **Hardened error handling everywhere.** Slash command, autocomplete, button/select and modal
  handlers no longer throw inside `InteractionCreate` listeners (which would surface as
  `unhandledRejection` and could crash the process); errors are logged and a safe fallback reply
  is attempted. `registerSlashCommands` now guards against attaching duplicate listeners.
- **`send`/`edit` are Components-V2 aware.** They auto-detect V2 components, set the
  `IsComponentsV2` flag automatically, and throw friendly errors when you mix V2 with
  `text`/`embeds`/`poll` (which Discord forbids).

#### Renamed
- **`src/classes/interactions/` → `src/classes/components/`** (buttons, modal, selectMenus now
  live there alongside the new `display.js`). *Why:* you asked to rename the `interactions`
  folder; "components" matches what these actually are (Discord message components).
  **Backwards compatible:** the public API did **not** change — `Buttons`, `SelectMenus`, `Modal`,
  `client.interaction(...)`, `client.modal(...)` and the `interactions:`/`modals:` handler paths
  all work exactly as before, so your existing beta bot does not need any changes.

### [1.0.0] - 2025-08-21
#### Feat
- Require role IDs to be strings and accept multiple roles for add/remove functions.
- Replaced client+serverID usage with message.guild to simplify API.
- Standardized error messages and made functions silent on success (library-friendly).
- **BREAKING CHANGE:**  
  The function signatures for `addRole` and `removeRole` have been updated.  
  - **Before:** `addRole({ userID, serverID, roleID }, client)`  
  - **Now:** `addRole({ user, roles: [] }, message)`  
  The same applies to `removeRole`.  
  You must update your code to the new format to avoid runtime errors.
